# restapicrud
Spring Boot REST APIs for CRUD Operations
